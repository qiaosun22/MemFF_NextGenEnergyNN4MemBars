Quantized weight for C200 mapping:
	conv1.weight_quantized.npy
	conv2.weight_quantized.npy
	fc1.weight_quantized.npy
	fc2.weight_quantized.npy

NN structure:
	FashionMNIST.onnx

NN training:
	train_main.py